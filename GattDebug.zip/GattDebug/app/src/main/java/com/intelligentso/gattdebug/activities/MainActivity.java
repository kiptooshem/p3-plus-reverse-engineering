package com.intelligentso.gattdebug.activities;

import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.widget.TextView;

import com.intelligentso.gattdebug.ble.BleService;
import com.intelligentso.gattdebug.DebugInterface;
import com.intelligentso.gattdebug.PreferencesManager;
import com.intelligentso.gattdebug.R;
import com.intelligentso.gattdebug.Utils;

import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    private PreferencesManager preferencesManager;

    private TextView textView;

    private List<BluetoothGattService> discoveredServices;
    private PrintWriter shellWriter;

    private BleService.BleServiceListener bleServiceListener =
            new BleService.BleServiceListener() {
        @Override
        public void onStateChanged(int state) {
            updateUi(state);
            if(shellWriter != null){
                shellWriter.println("State change: " + state);
            }
        }

        @Override
        public void onServicesDiscovered(List<BluetoothGattService> services) {
            discoveredServices = services;

            if(shellWriter != null){
                shellWriter.println("Services Discovered: ");
                for(BluetoothGattService service : services){
                    shellWriter.println(service.getUuid().toString());
                    for(BluetoothGattCharacteristic characteristic : service.getCharacteristics()){
                        shellWriter.println("\t" + characteristic.getUuid().toString());
                        shellWriter.println("\t Permissions: "
                                + Integer.toHexString(characteristic.getPermissions()));

                        shellWriter.println("\t\t Properties: "
                                + Integer.toHexString(characteristic.getProperties()));

                        shellWriter.println("\t\t Write type: "
                                + Integer.toHexString(characteristic.getWriteType()));


                        shellWriter.println("\t Current Value"
                                + Utils.getByteString(characteristic.getValue()));
                        for(BluetoothGattDescriptor descriptor: characteristic.getDescriptors()){
                            shellWriter.println("\t\t" + descriptor.getUuid().toString());
                            shellWriter.println("\t\t Permissions: "
                                    + Integer.toHexString(descriptor.getPermissions()));

                            shellWriter.println("\t\t Current Value"
                                    + Utils.getByteString(descriptor.getValue()));
                        }
                    }
                }
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGattCharacteristic characteristic) {
            if(shellWriter != null){
                shellWriter.println("\n\n CHARACTERISTICS READ \n\n");
                shellWriter.println("Characteristic: " + characteristic.getUuid().toString());
                shellWriter.println("Value: " + Utils.getByteString(characteristic.getValue()));
                shellWriter.println("\n\n END \n\n");
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGattCharacteristic characteristic) {
            if(shellWriter != null){
                shellWriter.println("\n\n CHARACTERISTICS CHANGE \n\n");
                shellWriter.println("Characteristic: " + characteristic.getUuid().toString());
                shellWriter.println("Value: " + Utils.getByteString(characteristic.getValue()));
                shellWriter.println("\n\n END \n\n");
            }
        }

        @Override
        public void onDescriptorRead(BluetoothGattDescriptor descriptor) {
            if(shellWriter != null){
                shellWriter.println("\n\n ON DESCRIPTOR READ \n\n");
                shellWriter.println("Characteristic: " + descriptor.getCharacteristic().getUuid().toString());
                shellWriter.println("Descriptor : " + descriptor.getUuid().toString());
                shellWriter.println("Value: " + Utils.getByteString(descriptor.getValue()));
                shellWriter.println("\n\n END \n\n");
            }
        }
    };

    private void updateUi(final int state){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                switch (state){
                    case BleService.STATE_CONNECTING:
                        textView.setText("Connecting");
                        break;
                    case BleService.STATE_CONNECTED:
                        textView.setText("Connected");
                        break;
                    case BleService.STATE_CONNECTION_FAILED:
                        textView.setText("Connection failed");
                        break;
                    case BleService.STATE_DISCONNECTED:
                        textView.setText("Disconnected");
                        break;
                }
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        textView = findViewById(R.id.text);

        preferencesManager = new PreferencesManager(this);

        if(preferencesManager.getDeviceName() == null
                || preferencesManager.getDeviceAddress() == null){
            startActivity(new Intent(this, DeviceScanActivity.class));
            finish();

            return;
        }

        runSocketIo();
        startBleService();
    }

    private void startBleService(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                if(BleService.init(MainActivity.this)){
                    BleService bleService = BleService.getInstance();
                    bleService.setListener(bleServiceListener);
                    bleService.connect(preferencesManager.getDeviceAddress());
                }
            }
        }).start();
    }

    private void runSocketIo(){
        DebugInterface.run(new DebugInterface.DebugInterfaceListener() {
            @Override
            public void onReady(PrintWriter writer) {
                shellWriter = writer;
            }

            @Override
            public boolean onCommand(PrintWriter writer, String command, String[] args, int argc) {

                Log.i(TAG, String.format("onCommand(): Command(%s), args(%s), argc(%d)", command,
                        Arrays.toString(args), argc));

                UUID serviceUUID;
                UUID characteristicUUID;
                UUID descriptorUUID;

                byte[] writeValue;

                if(command.equals("enable-notifications") && argc == 4){
                    serviceUUID = UUID.fromString(args[1]);
                    characteristicUUID = UUID.fromString(args[2]);
                    descriptorUUID = UUID.fromString(args[3]);

                    if(BleService.getInstance().enableDescriptorNotification(serviceUUID,
                            characteristicUUID, descriptorUUID)){
                        writer.println("\n\n TRUE \n\n");
                    }else{
                        writer.println("\n\n FALSE \n\n");
                    }

                    return true;
                }

                if(command.equals("write-value-char") && argc == 4){
                    serviceUUID = UUID.fromString(args[1]);
                    characteristicUUID = UUID.fromString(args[2]);
                    writeValue = Utils.fromHexString(args[3]);

                    if(BleService.getInstance()
                            .writeValue(writeValue, serviceUUID, characteristicUUID)){
                        writer.println("\n\n TRUE \n\n");
                    }else{
                        writer.println("\n\n FALSE \n\n");
                    }

                    return true;
                }

                if(command.equals("send-command") && argc == 2){
                    writeValue = Utils.fromHexString(args[1]);

                    if(BleService.getInstance()
                            .sendCommand(writeValue)){
                        writer.println("\n\n TRUE \n\n");
                    }else{
                        writer.println("\n\n FALSE \n\n");
                    }

                    return true;

                }

                if(command.equals("read") && argc == 3){
                    serviceUUID = UUID.fromString(args[1]);
                    characteristicUUID = UUID.fromString(args[2]);
                    if(BleService.getInstance()
                            .readCharacteristic(serviceUUID, characteristicUUID)){
                        writer.println("\n\n TRUE \n\n");
                    }else{
                        writer.println("\n\n FALSE \n\n");
                    }

                    return true;
                }

                /*switch (command){
                    case "enable-notifications":
                        if(argc < 4){
                            return false;
                        }

                        serviceUUID = UUID.fromString(args[1]);
                        characteristicUUID = UUID.fromString(args[2]);
                        descriptorUUID = UUID.fromString(args[3]);

                        if(BleService.getInstance().enableDescriptorNotification(serviceUUID,
                                characteristicUUID, descriptorUUID)){
                            writer.println("\n\n TRUE \n\n");
                        }else{
                            writer.println("\n\n FALSE \n\n");
                        }

                        break;
                    case "write-value-char":
                        if(argc < 4)
                            return false;

                        serviceUUID = UUID.fromString(args[1]);
                        characteristicUUID = UUID.fromString(args[2]);
                        writeValue = Utils.fromHexString(args[3]);

                        if(BleService.getInstance()
                                .writeValue(writeValue, serviceUUID, characteristicUUID)){
                            writer.println("\n\n TRUE \n\n");
                        }else{
                            writer.println("\n\n FALSE \n\n");
                        }
                         break;
                }*/

                return false;
            }
        });
    }
}
