package com.intelligentso.gattdebug;

import android.bluetooth.BluetoothGattCharacteristic;
import android.os.ParcelUuid;

public class Utils {
    public static byte[] fromHexString(final String encoded) {
        if ((encoded.length() % 2) != 0)
            throw new IllegalArgumentException("Input string must contain an even number of characters");

        final byte result[] = new byte[encoded.length()/2];
        final char enc[] = encoded.toCharArray();
        for (int i = 0; i < enc.length; i += 2) {
            StringBuilder curr = new StringBuilder(2);
            curr.append(enc[i]).append(enc[i + 1]);
            result[i/2] = (byte) Integer.parseInt(curr.toString(), 16);
        }
        return result;
    }

    public static String getByteString(byte[] data){
        if (data != null && data.length > 0) {
            final StringBuilder stringBuilder = new StringBuilder(data.length);
            for(byte byteChar : data)
                stringBuilder.append(String.format("%02X ", byteChar));

            return stringBuilder.toString();
        }
        return "";
    }

    public static boolean hasCharacteristicProperty(BluetoothGattCharacteristic characteristic,
                                                    int property){
        return (characteristic.getProperties() & property) > 0;
    }
}
