package com.intelligentso.gattdebug;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PreferencesManager {
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor prefsEditor;

    private int PRIVATE_MODE = 0;
    private static final String PREF_NAME = "gatt_debug_prefs";

    private static final String DEVICE_NAME = "device_name";
    private static final String DEVICE_ADDRESS = "device_address";

    private static final String INSTANCE_ID = "instance_id";
    private static final String ACCESS_TOKEN = "access_token";

    private static final String IS_FIRST_TIME_USE = "is_first_time_use";
    private static final String HAS_ANSWERED_ONBOARDING_DATA = "has_answered_on_boarding_data";

    private static final String AUTOMATIC_MEASURE = "automatic_measure";
    private static final String MEASURE_FREQUENCY = "measure_frequency";
    private static final String LAST_PERIODIC_COLLECTION = "last_periodic_collection";

    private static final String HAS_BEEN_REGISTERED = "has_been_registered";

    private static final String BED_TIME = "bed_time";
    private static final String WAKE_UP_TIME = "wake_up_time";
    //private static final String REGISTERED_EMAIL_ADDRESS = "registered_email_address";

    public PreferencesManager(Context context){
        sharedPreferences = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        prefsEditor = sharedPreferences.edit();
    }

    public String getDeviceName(){
        return sharedPreferences.getString(DEVICE_NAME, null);
    }

    public String getDeviceAddress(){
        return sharedPreferences.getString(DEVICE_ADDRESS, null);
    }

    public void setDeviceName(String deviceName){
        prefsEditor.putString(DEVICE_NAME, deviceName);
        prefsEditor.commit();
    }

    public void setDeviceAddress(String deviceAddress){
        prefsEditor.putString(DEVICE_ADDRESS, deviceAddress);
        prefsEditor.commit();
    }

    public String getInstanceId() {
        return sharedPreferences.getString(INSTANCE_ID, null);
    }

    public void setInstanceId(String token){
        prefsEditor.putString(INSTANCE_ID, token);
        prefsEditor.commit();
    }

    public void setAccessToken(String accessToken){
        prefsEditor.putString(ACCESS_TOKEN, accessToken);
        prefsEditor.commit();
    }

    public String getAccessToken(){
        return sharedPreferences.getString(ACCESS_TOKEN, null);
    }

    public boolean isFirstTimeUse(){
        return sharedPreferences.getBoolean(IS_FIRST_TIME_USE, true);
        //prefsEditor.putBoolean(IS_FIRST_TIME_USE, true);
        //prefsEditor.commit();
        //return isFirstTimeUse;
    }

    public void setFirsTimeUse(boolean isFirsTimeUse){
        prefsEditor.putBoolean(IS_FIRST_TIME_USE, isFirsTimeUse);
        prefsEditor.commit();
    }

    public boolean hasFinishedOnboardingData(){
        return  sharedPreferences.getBoolean(HAS_ANSWERED_ONBOARDING_DATA, false);
    }

    public void setHasAnsweredOnboardingData(boolean hasAnsweredOnboardingData){
        prefsEditor.putBoolean(HAS_ANSWERED_ONBOARDING_DATA, hasAnsweredOnboardingData);
        prefsEditor.commit();
    }

    public boolean doesAutomaticMeasure(){
        return true;
        //return sharedPreferences.getBoolean(AUTOMATIC_MEASURE, true);
    }

    public void setAutomaticMeasure(boolean automaticMeasure){
        prefsEditor.putBoolean(AUTOMATIC_MEASURE, automaticMeasure);
        prefsEditor.commit();
    }

    public int getMeasureFrequency(){
        return sharedPreferences.getInt(MEASURE_FREQUENCY, 30);
    }

    public void setMeasureFrequency(int frequency){
        prefsEditor.putInt(MEASURE_FREQUENCY, frequency);
        prefsEditor.commit();
    }

    public void setLastPeriodicCollection(Date date){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");

        prefsEditor.putString(LAST_PERIODIC_COLLECTION, simpleDateFormat.format(date));
        prefsEditor.commit();
    }


    public Date getLastPeriodicCollection(){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");

        String date = sharedPreferences.getString(LAST_PERIODIC_COLLECTION, null);

        if(date == null)
            return null;

        try {
            return simpleDateFormat.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return null;
    }

    public void setHasBeenRegistered(boolean hasBeenRegistered){
        prefsEditor.putBoolean(HAS_BEEN_REGISTERED, hasBeenRegistered);
        prefsEditor.commit();
    }

    public boolean hasBeenRegistered(){
        return sharedPreferences.getBoolean(HAS_BEEN_REGISTERED, false);
    }

    public void setBedTime(String bedTime){
        prefsEditor.putString(BED_TIME, bedTime);
        prefsEditor.commit();
    }

    public String getBedTime(){

        return sharedPreferences.getString(BED_TIME, "10:00");
    }

    public void setWakeUpTime(String wakeUpTime){

        prefsEditor.putString(WAKE_UP_TIME, wakeUpTime);
        prefsEditor.commit();
    }

    public String getWakeUpTime(){
        return sharedPreferences.getString(WAKE_UP_TIME, "05:00");
    }
}
