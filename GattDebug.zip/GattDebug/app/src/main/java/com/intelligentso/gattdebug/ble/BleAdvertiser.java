package com.intelligentso.gattdebug.ble;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.os.ParcelUuid;

import com.intelligentso.gattdebug.BLEUUIDUtils;
import com.intelligentso.gattdebug.Utils;

public class BleAdvertiser {

    private void advertise(BluetoothAdapter bluetoothAdapter, AdvertiseCallback advertiseCallback){
        BluetoothLeAdvertiser advertiser = bluetoothAdapter.getBluetoothLeAdvertiser();

        //ParcelUuid parcelUuid = P

        AdvertiseData advertiseData = new AdvertiseData.Builder()
                .addManufacturerData(0x7810, Utils.fromHexString("03E80065FE7DE5759F89"))
                .addServiceUuid(BLEUUIDUtils.parcelFromShortValue(0x180D))
                .addServiceUuid(BLEUUIDUtils.parcelFromShortValue(0xFEE7))
                .addServiceUuid(BLEUUIDUtils.parcelFromShortValue(0x180F))
                .addServiceUuid(BLEUUIDUtils.parcelFromShortValue(0x180A))
                .setIncludeDeviceName(true)
                .setIncludeTxPowerLevel(true)
                .build();

        AdvertiseSettings settings = new AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
                .setConnectable(true)
                .setTimeout(0)
                .build();

        advertiser.startAdvertising(settings, advertiseData, advertiseCallback);
    }
}
