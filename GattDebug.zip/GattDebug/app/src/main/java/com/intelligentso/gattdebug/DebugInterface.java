package com.intelligentso.gattdebug;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class DebugInterface {
    private static final String TAG = DebugInterface.class.getSimpleName();

    public interface DebugInterfaceListener{
        void onReady(PrintWriter writer);
        boolean onCommand(PrintWriter writer, String command, String[] args, int argc);
    }

    private static volatile DebugInterface instance;

    private final String SERVER = "192.168.100.4";
    private final int WRITER_PORT = 7000;
    private final int READER_PORT = 7001;

    private PrintWriter writer;
    private BufferedReader reader;
    private DebugInterface(){
        try {
            InetAddress serverAddr = InetAddress.getByName(SERVER);
            Socket socket = new Socket(serverAddr, WRITER_PORT);
            Socket readerSocket = new Socket(serverAddr, READER_PORT);

            writer = new PrintWriter(
                    new BufferedWriter(
                            new OutputStreamWriter(socket.getOutputStream())),
                    true);

            reader = new BufferedReader(new InputStreamReader(readerSocket.getInputStream()));
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void run(final DebugInterfaceListener listener){
        new Thread(new Runnable() {
            @Override
            public void run() {
                DebugInterface debugInterface = new DebugInterface();
                String promptShell = "ble-debug>";
                listener.onReady(debugInterface.writer);
                while (true){
                    try {
                        //debugInterface.writer.print(promptShell);

                        String shellInput = debugInterface.reader.readLine();
                        String[] tokens = shellInput.trim().split("\\s+");
                        if(tokens.length == 0){
                            continue;
                        }

                        //Log.i(TAG, "Command received: " + Arrays.toString(tokens));

                        String command = tokens[0];

                        if(command.equals("exit")){
                            break;
                        }

                        //debugInterface.writer.println("Unknown command");

                        if(!listener.onCommand(debugInterface.writer, command, tokens, tokens.length))
                            debugInterface.writer.println("Unknown command");

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }
}
