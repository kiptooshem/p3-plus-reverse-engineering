package com.intelligentso.gattdebug.ble;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattServer;
import android.bluetooth.BluetoothGattServerCallback;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.util.Log;

import com.intelligentso.gattdebug.Utils;

import java.util.List;
import java.util.UUID;

public class BleService {

    public interface BleServiceListener{
        void onStateChanged(int state);
        void onServicesDiscovered(List<BluetoothGattService> services);
        void onCharacteristicRead(BluetoothGattCharacteristic characteristic);
        void onCharacteristicChanged(BluetoothGattCharacteristic characteristic);
        void onDescriptorRead(BluetoothGattDescriptor descriptor);
    }

    private static final String TAG = BleService.class.getSimpleName();

    private static volatile BleService instance;

    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;
    private String mBluetoothDeviceAddress;
    private BluetoothGatt mBluetoothGatt;
    private Context context;

    private BleServiceListener listener;

    public static final int STATE_DISCONNECTED = 0;
    public static final int STATE_CONNECTING = 1;
    public static final int STATE_CONNECTED = 2;
    public static final int STATE_CONNECTION_FAILED = 3;
    public static final int STATE_READY = 4;

    public static final int STATE_NOT_SUPPORTED = 8;
    public static final int STATE_GENERAL_FAILURE = 9;
    public static final int STATE_UNABLE_TO_READ = 10;

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;

        if(listener != null)
            listener.onStateChanged(state);
    }

    public int state = STATE_DISCONNECTED;

    private BluetoothGattServer bluetoothGattServer;

    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicWrite(gatt, characteristic, status);

        }

        @Override
        public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            //super.onDescriptorRead(gatt, descriptor, status);
            if(listener != null)
                listener.onDescriptorRead(descriptor);
        }


        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            String intentAction;
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                Log.i(TAG, "Connected to GATT server.");
                // Attempts to discover services after successful connection.
                Log.i(TAG, "Attempting to start service discovery:" +
                        mBluetoothGatt.discoverServices());

                setState(STATE_CONNECTED);

            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                Log.i(TAG, "Disconnected from GATT server.");

                setState(STATE_DISCONNECTED);
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.w(TAG, "Number of discovered services: " + gatt.getServices().size());

                List<BluetoothGattService> discoveredServices = gatt.getServices();

                for(BluetoothGattService service : discoveredServices){

                    if(!service.getUuid().equals(UUID.fromString("be940000-7333-be46-b7ae-689e71722bd5")))
                        continue;

                    /*if(service.getUuid().equals(UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e")))
                        continue;*/

                    for(BluetoothGattCharacteristic characteristic : service.getCharacteristics()){

                        if(characteristic.getUuid().equals(UUID.fromString("be940001-7333-be46-b7ae-689e71722bd5"))
                        || characteristic.getUuid().equals(UUID.fromString("be940003-7333-be46-b7ae-689e71722bd5"))){
                            for(BluetoothGattDescriptor descriptor: characteristic.getDescriptors()){

                                if(Utils.hasCharacteristicProperty(characteristic,
                                        BluetoothGattCharacteristic.PROPERTY_INDICATE)){
                                    gatt.setCharacteristicNotification(characteristic, true);
                                    descriptor.setValue(BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
                                    gatt.writeDescriptor(descriptor);

                                    Log.i(TAG, "Indications enabled for :" + characteristic.getUuid().toString());
                                }

                                if(Utils.hasCharacteristicProperty(characteristic,
                                        BluetoothGattCharacteristic.PROPERTY_NOTIFY)){
                                    gatt.setCharacteristicNotification(characteristic, true);
                                    descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                                    gatt.writeDescriptor(descriptor);

                                    Log.i(TAG, "Notifications enabled for :" + characteristic.getUuid().toString());
                                }
                            }
                        }

                    }
                }

                /*BluetoothGattService p3Service = gatt.getService(
                        UUID.fromString("be940000-7333-be46-b7ae-689e71722bd5"));

                BluetoothGattCharacteristic p3Char = p3Service.getCharacteristic(
                        UUID.fromString("be940001-7333-be46-b7ae-689e71722bd5"));

                BluetoothGattDescriptor descriptor = p3Char.getDescriptor(
                        UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));

                gatt.setCharacteristicNotification(p3Char, true);
                descriptor.setValue(BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
                gatt.writeDescriptor(descriptor);*/

                if(listener != null){
                    listener.onServicesDiscovered(discoveredServices);
                }

                /*BluetoothGattService p3SensorService = gatt.getService(UUID.fromString("be940000-7333-be46-b7ae-689e71722bd5"));

                if(p3SensorService != null){
                    Log.d(TAG, "Found P3 sensor service");

                    BluetoothGattCharacteristic writerChar = p3SensorService.getCharacteristic(UUID.fromString("be940001-7333-be46-b7ae-689e71722bd5"));

                }*/

                //startGattServer(discoveredServices);

                // NOTE: Characteristics and their descriptors and in the service object


            } else {
                Log.w(TAG, "onServicesDiscovered received: " + status);
                setState(STATE_GENERAL_FAILURE);
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic,
                                         int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.i(TAG, "Characteristic read.");

                if(listener != null){
                    listener.onCharacteristicRead(characteristic);
                }

            }else{
                Log.w(TAG, "onCharacteristicRead received: " + status);
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt,
                                            BluetoothGattCharacteristic characteristic) {

            Log.i(TAG, "Characteristic changed!: " + characteristic.getUuid().toString());

            Log.i(TAG, "Received data: " + Utils.getByteString(characteristic.getValue()));

            if(listener != null){
                listener.onCharacteristicChanged(characteristic);
            }
        }
    };

    private BleService(Context context) {
        this.context = context;
    }

    public boolean enableGattCharacteristic(BluetoothGattCharacteristic characteristic){
        return mBluetoothGatt.setCharacteristicNotification(characteristic, true);
    }
    public boolean enableGattCharacteristic(UUID service, UUID characteristic){
        return enableGattCharacteristic(mBluetoothGatt.getService(service)
                .getCharacteristic(characteristic));
    }

    public boolean enableDescriptorNotification(BluetoothGattDescriptor descriptor){
        descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);

        return mBluetoothGatt.writeDescriptor(descriptor);
    }

    public boolean enableDescriptorIndications(BluetoothGattDescriptor descriptor){
        descriptor.setValue(BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
        return mBluetoothGatt.writeDescriptor(descriptor);
    }

    public boolean enableDescriptorIndications(UUID service, UUID characteristic, UUID descriptor){
        return this.enableDescriptorIndications(mBluetoothGatt.getService(service)
                .getCharacteristic(characteristic).getDescriptor(descriptor));
    }

    public boolean enableDescriptorNotification(UUID service, UUID characteristic, UUID descriptor){
        return this.enableDescriptorNotification(mBluetoothGatt.getService(service)
                .getCharacteristic(characteristic).getDescriptor(descriptor));
    }

    public static boolean init(Context context){
        if(instance == null){
            synchronized (BleService.class){
                if(instance == null){
                    instance = new BleService(context);
                    if(!instance.init()){
                        instance = null;
                        return false;
                    }

                    return true;
                }
            }
        }

        return true;
    }

    public void setListener(BleServiceListener listener){
        this.listener = listener;
    }

    public static BleService getInstance(){
        if(instance == null)
            throw new RuntimeException("Service not initialized");
        return instance;
    }

    private boolean init() {
        // For API level 18 and above, get a reference to BluetoothAdapter through
        // BluetoothManager.
        if (mBluetoothManager == null) {
            mBluetoothManager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
            if (mBluetoothManager == null) {
                Log.e(TAG, "Unable to initialize BluetoothManager.");
                return false;
            }
        }

        mBluetoothAdapter = mBluetoothManager.getAdapter();
        if (mBluetoothAdapter == null) {
            Log.e(TAG, "Unable to obtain a BluetoothAdapter.");
            return false;
        }

        return true;
    }

    public boolean connect(final String address) {
        if (mBluetoothAdapter == null || address == null) {
            Log.w(TAG, "BluetoothAdapter not initialized or unspecified address.");
            return false;
        }

        // Previously connected device.  Try to reconnect.
        if (address.equals(mBluetoothDeviceAddress)
                && mBluetoothGatt != null) {
            Log.i(TAG, "Trying to use an existing mBluetoothGatt for connection.");
            if (mBluetoothGatt.connect()) {
                setState(STATE_CONNECTING);

                mBluetoothGatt.discoverServices();
                return true;
            } else {
                setState(STATE_CONNECTION_FAILED);
                return false;
            }
        }

        final BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        if (device == null) {
            Log.w(TAG, "Device not found.  Unable to connect.");
            setState(STATE_CONNECTION_FAILED);
            return false;
        }
        // We want to directly connect to the device, so we are setting the autoConnect
        // parameter to false.
        mBluetoothGatt = device.connectGatt(this.context, false, mGattCallback);
        Log.i(TAG, "Trying to create a new connection.");
        mBluetoothDeviceAddress = address;

        setState(STATE_CONNECTING);
        return true;
    }

    private List<BluetoothGattService> getSupportedGattServices() {
        if (mBluetoothGatt == null) return null;

        return mBluetoothGatt.getServices();
    }

    public boolean writeValue(byte[] command, UUID service, UUID characteristic){
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized");
            return false;
        }

        Log.w(TAG, "Send command:" + Utils.getByteString(command));
        BluetoothGattCharacteristic rxCharacteristic = mBluetoothGatt
                .getService(service)
                .getCharacteristic(characteristic);

        rxCharacteristic.setValue(command);
        return mBluetoothGatt.writeCharacteristic(rxCharacteristic);
    }

    public boolean readCharacteristic(UUID service, UUID characteristic){
        return mBluetoothGatt
                .readCharacteristic(mBluetoothGatt.getService(service)
                        .getCharacteristic(characteristic));
    }

    public boolean sendCommand(byte[] command){
        BluetoothGattService p3SensorService = mBluetoothGatt
                .getService(UUID.fromString("be940000-7333-be46-b7ae-689e71722bd5"));

        if(p3SensorService != null){
            Log.d(TAG, "Found P3 sensor service");

            BluetoothGattCharacteristic writerChar = p3SensorService
                    .getCharacteristic(UUID.fromString("be940001-7333-be46-b7ae-689e71722bd5"));

            writerChar.setValue(command);
            return  mBluetoothGatt.writeCharacteristic(writerChar);
        }

        return false;
    }

    public void disconnect() {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized");
            setState(STATE_DISCONNECTED);
            return;
        }
        mBluetoothGatt.disconnect();
       setState(STATE_DISCONNECTED);
    }

    public void close() {
        if (mBluetoothGatt == null) {
            return;
        }
        mBluetoothGatt.close();
        mBluetoothGatt = null;
    }

    private BluetoothGattService getService(UUID uuid){
        return mBluetoothGatt.getService(uuid);
    }

    private BluetoothGattServer startGattServer(List<BluetoothGattService> services){
        BluetoothGattServer server = mBluetoothManager.openGattServer(context, new BluetoothGattServerCallback() {
            @Override
            public void onConnectionStateChange(BluetoothDevice device, int status, int newState) {
                super.onConnectionStateChange(device, status, newState);
            }

            @Override
            public void onServiceAdded(int status, BluetoothGattService service) {
                super.onServiceAdded(status, service);
            }

            @Override
            public void onCharacteristicReadRequest(BluetoothDevice device, int requestId, int offset, BluetoothGattCharacteristic characteristic) {
                super.onCharacteristicReadRequest(device, requestId, offset, characteristic);

                mBluetoothGatt.readCharacteristic(characteristic);
            }

            @Override
            public void onCharacteristicWriteRequest(BluetoothDevice device, int requestId, BluetoothGattCharacteristic characteristic, boolean preparedWrite, boolean responseNeeded, int offset, byte[] value) {
                super.onCharacteristicWriteRequest(device, requestId, characteristic, preparedWrite, responseNeeded, offset, value);

                mBluetoothGatt.writeCharacteristic(characteristic);
            }

            @Override
            public void onDescriptorReadRequest(BluetoothDevice device, int requestId, int offset, BluetoothGattDescriptor descriptor) {
                super.onDescriptorReadRequest(device, requestId, offset, descriptor);
            }

            @Override
            public void onDescriptorWriteRequest(BluetoothDevice device, int requestId, BluetoothGattDescriptor descriptor, boolean preparedWrite, boolean responseNeeded, int offset, byte[] value) {
                super.onDescriptorWriteRequest(device, requestId, descriptor, preparedWrite, responseNeeded, offset, value);
            }

            @Override
            public void onExecuteWrite(BluetoothDevice device, int requestId, boolean execute) {
                super.onExecuteWrite(device, requestId, execute);
            }

            @Override
            public void onNotificationSent(BluetoothDevice device, int status) {
                super.onNotificationSent(device, status);
            }

            @Override
            public void onMtuChanged(BluetoothDevice device, int mtu) {
                super.onMtuChanged(device, mtu);
            }

            @Override
            public void onPhyUpdate(BluetoothDevice device, int txPhy, int rxPhy, int status) {
                super.onPhyUpdate(device, txPhy, rxPhy, status);
            }

            @Override
            public void onPhyRead(BluetoothDevice device, int txPhy, int rxPhy, int status) {
                super.onPhyRead(device, txPhy, rxPhy, status);
            }
        });

        for (BluetoothGattService service: services) {
            server.addService(service);
        }

        return server;
    }
}
